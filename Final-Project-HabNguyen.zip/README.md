# README | Final Project
### Due: Friday, January 21st before 4:00pm Oberlin Time

As part of your submission, complete the responses below. Be sure to include your declaration of the Honor Code at the end of this file.

1. Names of anyone with whom you discussed the final project with:
Professor Molly
2. What did you learn during the process of creating your final project?
I learnt the hard way about the life of a programmer (debugging is so frustrated!)
3. What is one thing you wish you could have done differently?
I wish I had come up with something more easier, but it's still very fun to do this game and learn about the pyGame module
4. An estimate of how many hours you spent on the project:
50 hours
5. Honor Code Declaration: I have adhered to the Honor Code in this project
