# Progress Report
### Due: January 11th at 11:59pm Oberlin Time

This file will contain your Progress Report. Answer the prompts below to evaluate how well you were able to meet your intermediate goal(s).

### In a numbered list, briefly restate the intermediate goal(s) from your Project Proposal.
1. Figure out where I will write my program - replit
2. Decide my characters/Make the last change to the initial proposal - character: Creeper, obstacle: TNT 
3. Start writing my program 

### Which goal(s) were you able to acheieve?
All of them

### Which goal(s) were you not able to acheieve? 
#### Please describe what problem(s) you faced, and indicate if you are still stuck on any particular step.
I don't know if there is a way to convert creeper.py and tnt.py to png so that I can use those images in the game.py which is where i write the program for my game

### In a few sentences, descibe your next steps.
1. Figure out how to solve my problem
2. Continue to write my program
3. Learn more about the pygame module

