# Project Proposal
### Due: January 4th at 11:59pm Oberlin Time

This file will contain your Final Project Proposal. Answer the prompts below to outline your project. If you are struggling to think of ideas, refer to the [Project Overview](https://cs.oberlin.edu/~cs150/final-project/part-1/) for suggestions.

### What is the title of your project?
The cactus run (subjected to change)

### In 3-5 sentences, summarize what you want to accomplish. Provide enough detail so that I can understand your main idea, but try to keep things concise.
So you probably know about the Dinosaur game you can play when there is no internet connection. I plan to do something similar to it but for now I have yet to decide what character I want to insert in my game so I just reverse the role of the dinorsaur and cactus. Instead of the dinosaur having to jump over and avoid the cactus, now the cactus have to avoid the dinosaur. And the game will also rank the players in top 10. I think this idea is not unique so I will try to personalize it more. 

Updated project idea: I want to create a game similar to the dinosaur game using the  pygame module, with characters taken from the game minecraft (creeper and TNT) and desinged using the picture module. 


### In a numbered list, briefly describe your intermediate goal(s) (i.e., what you want to accomplish before lab on January 12/13th). 
#### Note that you will reflect on how well you were able to meet your intermediate goal(s) in your Progress Report.

1. Figure out where I will write my program 
2. Decide my characters/Make the last change to the initial proposal 
3. Start writing my program 