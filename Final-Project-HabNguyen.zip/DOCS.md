# Documentation
### Due: Friday, January 21st before 4:00pm Oberlin Time

This file will contain your project Documentation. Fill out the relevant sections to document your code.

## Summary
#### Briefly describe your program and what it does.
In the final project, I created a game using the pygame module. This game works similarly to the Chrome Dinosaur game. The player has a choice of two characters (Creeper and Zombie from the game Mincraft), and has to jump through obstacles (TNTs) by pressing the spacebar. Everytime the player sucessfully jump through 1 obstacle, they get one point. The game ends when the character collides with an obstacle. This final project uses the codes from https://github.com/punwai/Chrome-Dinosaur as references to calculate the movement and position of the characters and obstacles per game frame.

## Example Usage
#### Provide examples of how the user should run your program.
Firstly, my program ask for user input, which is to type in the filename of the character they want to use (either Creeper or Zombie). Then, the game is played by pressing spacebar to jump through obstacles, and it ends when the character crashes into an obstacle.

## Input
#### Describe any input(s) required from the user.
The user needs to type in the filename of the character they want to use ("creeper.png" or "zombie.png")

## Output
#### Describe any output(s) produced by your program.
The output is the game, the score they get during their gameplay, and their chosen character

## Known Issues
#### Describe any known bugs, including workarounds to keep your program running.
That the user has to type in a whole filename for the character they want to play is rather confusing, long, and prone to error, but I couldn't think of how to implement the try/except statement better elsewhere. Also, I couldn't find a way to export my the image of my characters with transparent background using the picture module, so I just switch the background color to white, so the pictures of my characters appear to have transparent background. 
